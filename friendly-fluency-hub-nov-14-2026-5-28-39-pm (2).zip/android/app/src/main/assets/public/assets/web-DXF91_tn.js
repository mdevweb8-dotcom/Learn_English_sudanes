import { r as WebPlugin } from "./index-DB1v97X0.js";
// node_modules/@capacitor/splash-screen/dist/esm/web.js
var SplashScreenWeb = class extends WebPlugin {
	async show(_options) {}
	async hide(_options) {}
};
export { SplashScreenWeb };
